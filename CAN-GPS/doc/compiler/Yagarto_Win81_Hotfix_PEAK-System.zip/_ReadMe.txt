Hotfix for Yagarto tool chain to work unter Windows 8.1
=======================================================
(PEAK-System, MG, 2014-09-26)

Symptom:
During compilation of an ARM project ("make" command) under Windows 8.1,
one or several application error windows pop up describing a problem with
rm.exe or other executable tools.

Cause:
The msys-1.0.dll that is part of the Yagarto Tools is not working correctly
under Windows 8.1.

Solution:
Replace the msys-1.0.dll in the Yagarto Tools directory with the one from this
ZIP file. In detail:

1. Locate the existing file msys-1.0.dll. By default it is residing in the
following Tools directory (if not changed during Yagarto Tools installation):
C:\yagarto-tools-20121018\bin

2. Rename the existing DLL in order to have a backup:
   Current name:  msys-1.0.dll (date: 2006-07-06)
   Backup name:   msys-1.0.dll.bak
   
3. Copy the DLL from this ZIP file to the Tools directory you've located above.
   New file:      msys-1.0.dll (date: 2012-11-22)

NOTE: This hotfix is provided by PEAK-System and is _not_ related to the
official Yagarto project. In case of questions, please contact PEAK-System
(e.g. via support@peak-system.com or www.peak-system.com/forum/).
